in 07PLF_CLient ist die CLient anwendung

in 07PLF_WebServer ist der Server

POST geht

nearby geht nit